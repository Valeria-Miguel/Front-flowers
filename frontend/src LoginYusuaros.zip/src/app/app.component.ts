import { Component, OnInit, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './services/auth.service'; // Asegúrate de que la ruta sea correcta

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  private authService = inject(AuthService); // Inyección para componentes standalone

  async ngOnInit() {
    try {
      const isAuthenticated = await this.authService.initializeAuthState();
      if (isAuthenticated) {
        console.log('Usuario autenticado detectado al iniciar');
      }
    } catch (error) {
      console.error('Error al inicializar estado de autenticación:', error);
    }
  }
}