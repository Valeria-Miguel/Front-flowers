import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Verificación síncrona del estado actual
  if (authService.isAuthenticated()) {
    return true;
  }

  // Redirección con URL de retorno
  router.navigate(['/login'], { 
    queryParams: { returnUrl: state.url } 
  }).catch(e => console.error('Navigation error:', e));
  
  return false;
};