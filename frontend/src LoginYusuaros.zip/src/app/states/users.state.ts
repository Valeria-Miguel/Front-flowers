// src/app/states/users.state.ts
import { User } from '../models/users.model';


// src/app/states/users.state.ts
export interface UsersState {
  users: User[];
  loading: boolean;
  loaded: boolean;
  error: string | null;
}

export const initialUsersState: UsersState = {
  users: [],
  loading: false,
  loaded: false,
  error: null
};