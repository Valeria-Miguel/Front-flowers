import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';
import { routes } from './app.routes';
import { hamburguesasReducer } from './reducers/hamburguesas.reducer';
import { HamburguesasEffects } from './effects/hamburguesas.effects';
import { usersReducer } from './reducers/users.reducer';  // Asegúrate que la ruta sea correcta
import { usersEffects } from './effects/users.effects';   // Asegúrate que la ruta sea correcta
import { pepsiReducer } from './reducers/pepsi.reducer';
import { PepsiEffects } from './effects/pepsi.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(),
    provideStore({ users: usersReducer }),
    provideEffects(usersEffects),
    provideStoreDevtools({
      maxAge: 25,
      logOnly: false // Para desarrollo
    })
  ]
};