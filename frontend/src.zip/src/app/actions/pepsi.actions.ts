import { createAction, props } from '@ngrx/store';
import { Pepsi } from '../models/pepsi.model';

// Acciones para cargar pepsis
export const loadPepsis = createAction('[Pepsi] Load Pepsis');
export const loadPepsisSuccess = createAction(
  '[Pepsi] Load Pepsis Success',
  props<{ pepsis: Pepsi[] }>()
);
export const loadPepsisFailure = createAction(
  '[Pepsi] Load Pepsis Failure',
  props<{ error: string }>()
);

// Acciones para crear un pepsi
export const createPepsi = createAction(
  '[Pepsi] Create Pepsi',
  props<{ pepsi: Pepsi }>()
);
export const createPepsiSuccess = createAction(
  '[Pepsi] Create Pepsi Success',
  props<{ pepsi: Pepsi }>()
);
export const createPepsiFailure = createAction(
  '[Pepsi] Create Pepsi Failure',
  props<{ error: string }>()
);

// Acciones para actualizar un pepsi
export const updatePepsi = createAction(
  '[Pepsi] Update Pepsi',
  props<{ id: number; pepsi: Pepsi }>()
);
export const updatePepsiSuccess = createAction(
  '[Pepsi] Update Pepsi Success',
  props<{ pepsi: Pepsi }>()
);
export const updatePepsiFailure = createAction(
  '[Pepsi] Update Pepsi Failure',
  props<{ error: string }>()
);

// Acciones para eliminar un pepsi
export const deletePepsi = createAction(
  '[Pepsi] Delete Pepsi',
  props<{ id: number }>()
);
export const deletePepsiSuccess = createAction(
  '[Pepsi] Delete Pepsi Success',
  props<{ id: number }>()
);
export const deletePepsiFailure = createAction(
  '[Pepsi] Delete Pepsi Failure',
  props<{ error: string }>()
);