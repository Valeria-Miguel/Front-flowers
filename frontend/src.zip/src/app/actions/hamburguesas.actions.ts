import { createAction, props } from '@ngrx/store';
import { Hamburguesa } from '../models/hamburguesas.model';

// Load Hamburguesas
export const loadHamburguesas = createAction('[Hamburguesas] Load Hamburguesas');
export const loadHamburguesasSuccess = createAction(
  '[Hamburguesas] Load Hamburguesas Success',
  props<{ hamburguesas: Hamburguesa[] }>()
);
export const loadHamburguesasFailure = createAction(
  '[Hamburguesas] Load Hamburguesas Failure',
  props<{ error: string }>()
);

// Create Hamburguesa
export const createHamburguesa = createAction(
  '[Hamburguesas] Create Hamburguesa',
  props<{ hamburguesa: Hamburguesa }>()
);
export const createHamburguesaSuccess = createAction(
  '[Hamburguesas] Create Hamburguesa Success',
  props<{ hamburguesa: Hamburguesa }>()
);
export const createHamburguesaFailure = createAction(
  '[Hamburguesas] Create Hamburguesa Failure',
  props<{ error: string }>()
);

// Update Hamburguesa
export const updateHamburguesa = createAction(
  '[Hamburguesas] Update Hamburguesa',
  props<{ id: number; hamburguesa: Hamburguesa }>()
);
export const updateHamburguesaSuccess = createAction(
  '[Hamburguesas] Update Hamburguesa Success',
  props<{ hamburguesa: Hamburguesa }>()
);
export const updateHamburguesaFailure = createAction(
  '[Hamburguesas] Update Hamburguesa Failure',
  props<{ error: string }>()
);

// Delete Hamburguesa
export const deleteHamburguesa = createAction(
  '[Hamburguesas] Delete Hamburguesa',
  props<{ id: number }>()
);
export const deleteHamburguesaSuccess = createAction(
  '[Hamburguesas] Delete Hamburguesa Success',
  props<{ id: number }>()
);
export const deleteHamburguesaFailure = createAction(
  '[Hamburguesas] Delete Hamburguesa Failure',
  props<{ error: string }>()
);