import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Hamburguesa } from '../models/hamburguesas.model';

@Injectable({
  providedIn: 'root'
})
export class HamburguesasService {
  private apiUrl = 'http://localhost:8000/api/hamburguesas/';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getAccessToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  getHamburguesas(): Observable<Hamburguesa[]> {
    return this.http.get<Hamburguesa[]>(this.apiUrl, { headers: this.getHeaders() });
  }

  getHamburguesa(id: number): Observable<Hamburguesa> {
    return this.http.get<Hamburguesa>(`${this.apiUrl}${id}/`, { headers: this.getHeaders() });
  }

  createHamburguesa(hamburguesa: Hamburguesa): Observable<Hamburguesa> {
    return this.http.post<Hamburguesa>(this.apiUrl, hamburguesa, { headers: this.getHeaders() });
  }

  updateHamburguesa(id: number, hamburguesa: Hamburguesa): Observable<Hamburguesa> {
    return this.http.put<Hamburguesa>(`${this.apiUrl}${id}/`, hamburguesa, { headers: this.getHeaders() });
  }

  deleteHamburguesa(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}${id}/`, { headers: this.getHeaders() });
  }
}