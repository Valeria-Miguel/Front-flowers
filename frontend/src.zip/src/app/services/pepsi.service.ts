import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Pepsi } from '../models/pepsi.model';

@Injectable({
  providedIn: 'root'
})
export class PepsiService {
  private apiUrl = 'http://localhost:8000/api/pepsi/';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getAccessToken();
    if (!token) {
      throw new Error('No access token available');
    }
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  getPepsis(): Observable<Pepsi[]> {
    return this.http.get<Pepsi[]>(this.apiUrl, { headers: this.getHeaders() });
  }

  getPepsi(id: number): Observable<Pepsi> {
    return this.http.get<Pepsi>(`${this.apiUrl}${id}/`, { headers: this.getHeaders() });
  }

  createPepsi(pepsi: Pepsi): Observable<Pepsi> {
    return this.http.post<Pepsi>(this.apiUrl, pepsi, { headers: this.getHeaders() });
  }

  updatePepsi(id: number, pepsi: Pepsi): Observable<Pepsi> {
    return this.http.put<Pepsi>(`${this.apiUrl}${id}/`, pepsi, { headers: this.getHeaders() });
  }

  deletePepsi(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}${id}/`, { headers: this.getHeaders() });
  }
}