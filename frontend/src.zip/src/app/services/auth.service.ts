import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators'; 
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://127.0.0.1:10000/api/';
  private userSubject = new BehaviorSubject<any>(null);
  private accessToken: string | null = null;
  private refreshToken: string | null = null;

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    this.loadInitialState();
  }

  private loadInitialState(): void {
    const user = localStorage.getItem('user');
    const accessToken = localStorage.getItem('access_token');
    const refreshToken = localStorage.getItem('refresh_token');

    if (user && accessToken && refreshToken) {
      this.userSubject.next(JSON.parse(user));
      this.accessToken = accessToken;
      this.refreshToken = refreshToken;
    }
  }

  login(username: string, email: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}auth/token/`, { username, email, password }).pipe(
      tap(response => {
        try {
          // Verificación exhaustiva de la respuesta
          const accessToken = response?.access || response?.access_token;
          const refreshToken = response?.refresh || response?.refresh_token;
          
          if (!accessToken || !refreshToken) {
            throw new Error('La respuesta no contiene tokens válidos');
          }

          // Almacenamiento con verificación
          this.saveToLocalStorage('access_token', accessToken);
          this.saveToLocalStorage('refresh_token', refreshToken);
          
          const userData = { username, email };
          this.saveToLocalStorage('user', JSON.stringify(userData));
          
          this.userSubject.next(userData);
          this.router.navigate(['/dashboard']);
          
          console.log('Tokens guardados:', { 
            accessToken: !!accessToken, 
            refreshToken: !!refreshToken 
          });
          
        } catch (storageError) {
          console.error('Error al guardar en localStorage:', storageError);
          throw storageError;
        }
      }),
      catchError(error => {
        console.error('Error en la petición de login:', error);
        return throwError(() => error);
      })
    );
  }

  private saveToLocalStorage(key: string, value: string): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(key, value);
        console.log(`Guardado exitoso en localStorage (${key})`);
      } else {
        throw new Error('localStorage no está disponible');
      }
    } catch (error) {
      console.error(`Error al guardar ${key} en localStorage:`, error);
      throw error;
    }
  }
  private setAuthData(username: string, email: string): void {
    if (!this.accessToken || !this.refreshToken) {
      throw new Error('Tokens not available');
    }

    // Almacenar tokens con verificación
    localStorage.setItem('access_token', this.accessToken);
    localStorage.setItem('refresh_token', this.refreshToken);

    // Crear y almacenar datos básicos del usuario
    const userData = { username, email };
    this.userSubject.next(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  }

  register(username: string, email: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}users/register/`, { username, email, password });
  }



  refreshAccessToken(): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}token/refresh/`, { refresh: this.refreshToken }).pipe(
      tap(response => {
        this.accessToken = response.access;
        if (this.accessToken) {
          localStorage.setItem('access_token', this.accessToken);
        }
      })
    );
  }

  logout(): void {
    this.accessToken = null;
    this.refreshToken = null;
    this.userSubject.next(null);
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
  }

  getAccessToken(): string | null {
    return this.accessToken;
  }

  getUser(): Observable<any> {
    return this.userSubject.asObservable();
  }

  isAuthenticated(): boolean {
    return !!this.accessToken;
  }
}