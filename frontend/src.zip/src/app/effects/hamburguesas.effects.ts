import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, exhaustMap, map, tap } from 'rxjs/operators';
import { HamburguesasService } from '../services/hamburguesas.service';
import * as HamburguesasActions from '../actions/hamburguesas.actions';
import { Hamburguesa } from '../models/hamburguesas.model';

@Injectable()
export class HamburguesasEffects {
  private actions$ = inject(Actions);
  private hamburguesasService = inject(HamburguesasService);

  loadHamburguesas$ = createEffect(() =>
    this.actions$.pipe(
      ofType(HamburguesasActions.loadHamburguesas),
      tap(() => console.log('Effect triggered: loadHamburguesas')),
      exhaustMap(() =>
        this.hamburguesasService.getHamburguesas().pipe(
          tap(hamburguesas => console.log('API response:', hamburguesas)),
          map((hamburguesas: Hamburguesa[]) =>
            HamburguesasActions.loadHamburguesasSuccess({ hamburguesas })
          ),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              HamburguesasActions.loadHamburguesasFailure({
                error: error.message || 'Failed to load hamburguesas'
              })
            )
          )
        )
      )
    )
  );

  createHamburguesa$ = createEffect(() =>
    this.actions$.pipe(
      ofType(HamburguesasActions.createHamburguesa),
      tap(() => console.log('Effect triggered: createHamburguesa')),
      exhaustMap(({ hamburguesa }) =>
        this.hamburguesasService.createHamburguesa(hamburguesa).pipe(
          tap(hamburguesa => console.log('API response:', hamburguesa)),
          map((hamburguesa: Hamburguesa) =>
            HamburguesasActions.createHamburguesaSuccess({ hamburguesa })
          ),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              HamburguesasActions.createHamburguesaFailure({
                error: error.message || 'Failed to create hamburguesa'
              })
            )
          )
        )
      )
    )
  );

  updateHamburguesa$ = createEffect(() =>
    this.actions$.pipe(
      ofType(HamburguesasActions.updateHamburguesa),
      tap(() => console.log('Effect triggered: updateHamburguesa')),
      exhaustMap(({ id, hamburguesa }) =>
        this.hamburguesasService.updateHamburguesa(id, hamburguesa).pipe(
          tap(hamburguesa => console.log('API response:', hamburguesa)),
          map((hamburguesa: Hamburguesa) =>
            HamburguesasActions.updateHamburguesaSuccess({ hamburguesa })
          ),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              HamburguesasActions.updateHamburguesaFailure({
                error: error.message || 'Failed to update hamburguesa'
              })
            )
          )
        )
      )
    )
  );

  deleteHamburguesa$ = createEffect(() =>
    this.actions$.pipe(
      ofType(HamburguesasActions.deleteHamburguesa),
      tap(() => console.log('Effect triggered: deleteHamburguesa')),
      exhaustMap(({ id }) =>
        this.hamburguesasService.deleteHamburguesa(id).pipe(
          tap(() => console.log('API response: delete successful')),
          map(() => HamburguesasActions.deleteHamburguesaSuccess({ id })),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              HamburguesasActions.deleteHamburguesaFailure({
                error: error.message || 'Failed to delete hamburguesa'
              })
            )
          )
        )
      )
    )
  );
}