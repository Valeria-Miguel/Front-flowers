import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, exhaustMap, map, tap } from 'rxjs/operators';
import { PepsiService } from '../services/pepsi.service';
import * as PepsiActions from '../actions/pepsi.actions';
import { Pepsi } from '../models/pepsi.model';

@Injectable()
export class PepsiEffects {
  private actions$ = inject(Actions);
  private pepsiService = inject(PepsiService);

  loadPepsis$ = createEffect(() =>
    this.actions$.pipe(
      ofType(PepsiActions.loadPepsis),
      tap(() => console.log('Effect triggered: loadPepsis')),
      exhaustMap(() =>
        this.pepsiService.getPepsis().pipe(
          tap(pepsis => console.log('API response:', pepsis)),
          map((pepsis: Pepsi[]) =>
            PepsiActions.loadPepsisSuccess({ pepsis })
          ),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              PepsiActions.loadPepsisFailure({
                error: error.message || 'Failed to load pepsis'
              })
            )
          )
        )
      )
    )
  );

  createPepsi$ = createEffect(() =>
    this.actions$.pipe(
      ofType(PepsiActions.createPepsi),
      tap(() => console.log('Effect triggered: createPepsi')),
      exhaustMap(({ pepsi }) =>
        this.pepsiService.createPepsi(pepsi).pipe(
          tap(pepsi => console.log('API response:', pepsi)),
          map((pepsi: Pepsi) =>
            PepsiActions.createPepsiSuccess({ pepsi })
          ),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              PepsiActions.createPepsiFailure({
                error: error.message || 'Failed to create pepsi'
              })
            )
          )
        )
      )
    )
  );

  updatePepsi$ = createEffect(() =>
    this.actions$.pipe(
      ofType(PepsiActions.updatePepsi),
      tap(() => console.log('Effect triggered: updatePepsi')),
      exhaustMap(({ id, pepsi }) =>
        this.pepsiService.updatePepsi(id, pepsi).pipe(
          tap(pepsi => console.log('API response:', pepsi)),
          map((pepsi: Pepsi) =>
            PepsiActions.updatePepsiSuccess({ pepsi })
          ),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              PepsiActions.updatePepsiFailure({
                error: error.message || 'Failed to update pepsi'
              })
            )
          )
        )
      )
    )
  );

  deletePepsi$ = createEffect(() =>
    this.actions$.pipe(
      ofType(PepsiActions.deletePepsi),
      tap(() => console.log('Effect triggered: deletePepsi')),
      exhaustMap(({ id }) =>
        this.pepsiService.deletePepsi(id).pipe(
          tap(() => console.log('API response: delete successful')),
          map(() => PepsiActions.deletePepsiSuccess({ id })),
          tap(() => console.log('Success action dispatched')),
          catchError(error =>
            of(
              PepsiActions.deletePepsiFailure({
                error: error.message || 'Failed to delete pepsi'
              })
            )
          )
        )
      )
    )
  );
}