import { createFeatureSelector, createSelector } from '@ngrx/store';
import { HamburguesasState } from '../states/hamburguesas.state';

export const selectHamburguesasState = createFeatureSelector<HamburguesasState>('hamburguesas');

export const selectAllHamburguesas = createSelector(
  selectHamburguesasState,
  (state) => state.hamburguesas
);

export const selectHamburguesasLoading = createSelector(
  selectHamburguesasState,
  (state) => state.loading
);

export const selectHamburguesasError = createSelector(
  selectHamburguesasState,
  (state) => state.error
);

export const selectHamburguesasLoaded = createSelector(
  selectHamburguesasState,
  (state) => state.loaded
);