import { createFeatureSelector, createSelector } from '@ngrx/store';
import { PepsiState } from '../states/pepsi.state';

export const selectPepsiState = createFeatureSelector<PepsiState>('pepsi');

export const selectAllPepsis = createSelector(
  selectPepsiState,
  (state: PepsiState) => state.pepsis
);

export const selectPepsisLoading = createSelector(
  selectPepsiState,
  (state: PepsiState) => state.loading
);

export const selectPepsisLoaded = createSelector(
  selectPepsiState,
  (state: PepsiState) => state.loaded
);

export const selectPepsisError = createSelector(
  selectPepsiState,
  (state: PepsiState) => state.error
);