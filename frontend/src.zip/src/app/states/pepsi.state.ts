import { Pepsi } from '../models/pepsi.model';

export interface PepsiState {
  pepsis: Pepsi[];
  loading: boolean;
  loaded: boolean;
  error: string | null;
}

export const initialPepsiState: PepsiState = {
  pepsis: [],
  loading: false,
  loaded: false,
  error: null
};