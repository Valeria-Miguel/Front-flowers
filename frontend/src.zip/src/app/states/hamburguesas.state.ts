import { Hamburguesa } from '../models/hamburguesas.model';

export interface HamburguesasState {
  hamburguesas: Hamburguesa[];
  loading: boolean;
  loaded: boolean; // Track if data has been loaded
  error: string | null;
}

export const initialHamburguesasState: HamburguesasState = {
  hamburguesas: [],
  loading: false,
  loaded: false, // Initially false
  error: null
};