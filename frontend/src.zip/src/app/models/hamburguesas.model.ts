export interface Hamburguesa {
    id?: number;
    name: string;
    ingredientes: string;
    price: number;
    client: string;
  }