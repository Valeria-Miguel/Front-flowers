export interface Pepsi {
    id?: number;
    name: string;
    price: number;
    quantity: number;
}
