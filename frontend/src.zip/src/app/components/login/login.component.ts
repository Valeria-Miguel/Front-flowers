import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true, // <-- Esto marca el componente como standalone
  imports: [CommonModule, ReactiveFormsModule], // <-- Importaciones necesarias
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  // En tu LoginComponent (controlas la redirección):
onSubmit(): void {
  if (this.loginForm.valid) {
    const { username, email, password } = this.loginForm.value;
    this.authService.login(username, email, password).subscribe({
      next: () => {
        this.router.navigate(['/dashboard']); // Redirección aquí
      },
      error: (err) => {
        this.errorMessage = 'Credenciales incorrectas';
        console.error('Login error:', err);
      }
    });
  }
}
}