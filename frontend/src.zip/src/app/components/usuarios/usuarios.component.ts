// src/app/components/usuarios/usuarios.component.ts
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { User } from '../../models/users.model';
import { loadUsers, deleteUser } from '../../actions/users.actions';
import { selectAllUsers, selectUsersLoading } from '../../selectors/users.selectors';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent {
  private store = inject(Store);
  
  // Añade el signo de interrogación para manejar posibles undefined
  users$: Observable<User[]> = this.store.select(selectAllUsers);
  loading$: Observable<boolean> = this.store.select(selectUsersLoading);

  constructor() {
    this.store.dispatch(loadUsers());
  }

  deleteUser(id?: number): void {  // Hacer el id opcional
    if (id && confirm('¿Estás seguro de eliminar este usuario?')) {
      this.store.dispatch(deleteUser({ id }));
    }
  }
}