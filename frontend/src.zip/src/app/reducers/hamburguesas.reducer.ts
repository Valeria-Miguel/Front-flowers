import { createReducer, on } from '@ngrx/store';
import * as HamburguesasActions from '../actions/hamburguesas.actions';
import { initialHamburguesasState } from '../states/hamburguesas.state';

export const hamburguesasReducer = createReducer(
  initialHamburguesasState,
  on(HamburguesasActions.loadHamburguesas, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(HamburguesasActions.loadHamburguesasSuccess, (state, { hamburguesas }) => ({
    ...state,
    hamburguesas,
    loading: false,
    loaded: true // Set to true when hamburguesas are successfully loaded
  })),
  on(HamburguesasActions.loadHamburguesasFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false
  })),

  on(HamburguesasActions.createHamburguesa, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(HamburguesasActions.createHamburguesaSuccess, (state, { hamburguesa }) => ({
    ...state,
    hamburguesas: [...state.hamburguesas, hamburguesa],
    loading: false,
    loaded: true
  })),
  on(HamburguesasActions.createHamburguesaFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false
  })),

  on(HamburguesasActions.updateHamburguesa, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(HamburguesasActions.updateHamburguesaSuccess, (state, { hamburguesa }) => ({
    ...state,
    hamburguesas: state.hamburguesas.map(h => h.id === hamburguesa.id ? hamburguesa : h),
    loading: false,
    loaded: true
  })),
  on(HamburguesasActions.updateHamburguesaFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false
  })),

  on(HamburguesasActions.deleteHamburguesa, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(HamburguesasActions.deleteHamburguesaSuccess, (state, { id }) => ({
    ...state,
    hamburguesas: state.hamburguesas.filter(h => h.id !== id),
    loading: false,
    loaded: true
  })),
  on(HamburguesasActions.deleteHamburguesaFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false
  }))
);