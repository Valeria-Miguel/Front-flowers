import { createReducer, on } from '@ngrx/store';
import { PepsiState, initialPepsiState } from '../states/pepsi.state';
import * as PepsiActions from '../actions/pepsi.actions';

export const pepsiReducer = createReducer(
  initialPepsiState,

  // Cargar pepsis
  on(PepsiActions.loadPepsis, state => ({
    ...state,
    loading: true,
    loaded: false,
    error: null
  })),
  on(PepsiActions.loadPepsisSuccess, (state, { pepsis }) => ({
    ...state,
    pepsis,
    loading: false,
    loaded: true,
    error: null
  })),
  on(PepsiActions.loadPepsisFailure, (state, { error }) => ({
    ...state,
    loading: false,
    loaded: false,
    error
  })),

  // Crear pepsi
  on(PepsiActions.createPepsi, state => ({
    ...state,
    loading: true,
    error: null
  })),
  on(PepsiActions.createPepsiSuccess, (state, { pepsi }) => ({
    ...state,
    pepsis: [...state.pepsis, pepsi],
    loading: false,
    error: null
  })),
  on(PepsiActions.createPepsiFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // Actualizar pepsi
  on(PepsiActions.updatePepsi, state => ({
    ...state,
    loading: true,
    error: null
  })),
  on(PepsiActions.updatePepsiSuccess, (state, { pepsi }) => ({
    ...state,
    pepsis: state.pepsis.map(item => (item.id === pepsi.id ? pepsi : item)),
    loading: false,
    error: null
  })),
  on(PepsiActions.updatePepsiFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // Eliminar pepsi
  on(PepsiActions.deletePepsi, state => ({
    ...state,
    loading: true,
    error: null
  })),
  on(PepsiActions.deletePepsiSuccess, (state, { id }) => ({
    ...state,
    pepsis: state.pepsis.filter(item => item.id !== id),
    loading: false,
    error: null
  })),
  on(PepsiActions.deletePepsiFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  }))
);